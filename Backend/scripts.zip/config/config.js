// backend/config/config.js
module.exports = {
    JWT_SECRET: process.env.JWT_SECRET || 'Rishi@1995',
    PORT: process.env.PORT || 5000,
  };
  